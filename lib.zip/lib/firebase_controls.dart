import 'package:cloud_firestore/cloud_firestore.dart';
import 'dataclasses.dart';

class JobsController{
  final CollectionReference collection =
  FirebaseFirestore.instance.collection('jobs');
  Future<DocumentReference> addJob(Job job) {
    return collection.add(job.toFirestore());
  }
}

class ResultsController{
  final CollectionReference collection =
  FirebaseFirestore.instance.collection('results');
  Stream<QuerySnapshot> getStream() {
    return collection.snapshots();
  }
  Future<Result> waitForResult (String ID) async {
    final docRef = collection.doc(ID);
    String result = "";
    docRef.snapshots().listen(
          (event)
          {
            print("current data: ${event.data()}");
            result = event.data().toString();
          },
      onError: (error) => print("Listen failed: $error"),
    );
    print("=========================");
    print(result);
    print("=========================");
    while(result=="null" || result == "") {
      await Future.delayed(Duration(seconds: 1));
    }
    return Result(answer: 'answer',summary: 'summary');
  }
}