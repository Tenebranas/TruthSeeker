import 'package:flutter/material.dart';
import 'inputpage.dart';
import 'resultpage.dart';

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;

  void _incrementCounter() {
    setState(() {
      _counter++;
      }
    );
  }

  @override
  Widget build(BuildContext context) {
    const TextStyle buttonTextStyle = const TextStyle(fontSize: 20);
    const TextStyle labelStyle = const TextStyle(fontSize: 20, fontWeight: FontWeight.bold);

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            TextButton(style: ButtonStyle(
              foregroundColor: MaterialStateProperty.all<Color>(Colors.lightBlue),
              backgroundColor: MaterialStateProperty.all<Color>(Colors.lightBlueAccent),
            ),
              child: const Text("input question",
                style: buttonTextStyle,
              ),
              onPressed: (){
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MyInputPage(title: "Input Question")),
                );
              },
            ),
            Text("or check out...", style: TextStyle(fontSize: 20, color: Colors.blue)),

            Padding(padding: const EdgeInsets.all(10),
              child: Text("Trending Questions",
                  style: labelStyle),),

            Padding(padding: const EdgeInsets.all(5),
              child: TextButton(style: ButtonStyle(
                foregroundColor: MaterialStateProperty.all<Color>(Colors.lightBlue),
                backgroundColor: MaterialStateProperty.all<Color>(Colors.lightBlueAccent),
              ),
                  child: const Text("Q1: xxxxx",
                    style: buttonTextStyle,
                  ),
                  onPressed: (){
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => MyResultPage()),
                    );
                  }
                ),
              ),

            Padding(padding: const EdgeInsets.all(5),
              child: TextButton(style: ButtonStyle(
                foregroundColor: MaterialStateProperty.all<Color>(Colors.lightBlue),
                backgroundColor: MaterialStateProperty.all<Color>(Colors.lightBlueAccent),
              ),
                  child: const Text("Q2: xxxxx",
                    style: buttonTextStyle,
                  ),
                  onPressed: (){
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => MyResultPage()),
                    );
                  }
                ),
              ),

            Padding(padding: const EdgeInsets.all(5),
              child: TextButton(style: ButtonStyle(
                foregroundColor: MaterialStateProperty.all<Color>(Colors.lightBlue),
                backgroundColor: MaterialStateProperty.all<Color>(Colors.lightBlueAccent),
              ),
                  child: const Text("Q3: xxxxx",
                    style: buttonTextStyle,
                  ),
                  onPressed: (){
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => MyResultPage()),
                    );
                  }
                ),
              ),

            Padding(padding: const EdgeInsets.all(10),
              child: Text("Latest Questions",
                  style: labelStyle),),

            Padding(padding: const EdgeInsets.all(5),
              child: TextButton(style: ButtonStyle(
                foregroundColor: MaterialStateProperty.all<Color>(Colors.lightBlue),
                backgroundColor: MaterialStateProperty.all<Color>(Colors.lightBlueAccent),
              ),
                  child: const Text("Q1: xxxxx",
                    style: buttonTextStyle,
                  ),
                  onPressed: (){
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => MyResultPage()),
                    );
                  }
                ),
              ),

            Padding(padding: const EdgeInsets.all(5),
              child: TextButton(style: ButtonStyle(
                foregroundColor: MaterialStateProperty.all<Color>(Colors.lightBlue),
                backgroundColor: MaterialStateProperty.all<Color>(Colors.lightBlueAccent),
              ),
                  child: const Text("Q2: xxxxx",
                    style: buttonTextStyle,
                  ),
                  onPressed: (){
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => MyResultPage()),
                    );
                  }
                ),
              ),

            Padding(padding: const EdgeInsets.all(10),
              child: Text("Most Controversial Questions",
                  style: labelStyle),),

            Padding(padding: const EdgeInsets.all(5),
              child: TextButton(style: ButtonStyle(
                foregroundColor: MaterialStateProperty.all<Color>(Colors.lightBlue),
                backgroundColor: MaterialStateProperty.all<Color>(Colors.lightBlueAccent),
              ),
                  child: const Text("Q1: xxxxx",
                    style: buttonTextStyle,
                  ),
                  onPressed: (){
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => MyResultPage()),
                    );
                  }
                ),
              ),

            Padding(padding: const EdgeInsets.all(5),
              child: TextButton(style: ButtonStyle(
                foregroundColor: MaterialStateProperty.all<Color>(Colors.lightBlue),
                backgroundColor: MaterialStateProperty.all<Color>(Colors.lightBlueAccent),
              ),
                  child: const Text("Q2: xxxxx",
                    style: buttonTextStyle,
                  ),
                  onPressed: (){
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => MyResultPage()),
                    );
                }
              ),
            ),
          ],
        ),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}