import 'package:flutter/material.dart';

class MyResultPage extends StatefulWidget {
   const MyResultPage({super.key}): question = 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';

  final String question;
  MyResultPage.fromInput(this.question);

  @override
  State<MyResultPage> createState() => _MyResultPageState();
}

class _MyResultPageState extends State<MyResultPage> {

  @override
  Widget build(BuildContext context) {
    const TextStyle buttonTextStyle = const TextStyle(fontSize: 20);
    const TextStyle labelStyle = const TextStyle(fontSize: 20, fontWeight: FontWeight.bold);
    const TextStyle labelStyle2 = const TextStyle(fontSize: 20);

    return Scaffold(
      appBar: AppBar(
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[

            Container(decoration: BoxDecoration(border: Border.all(color: Colors.grey, width:5)),
              child: Row(
                children: [
                  Padding(padding: const EdgeInsets.all(10),
                  child: Text('Question:',
                      style: labelStyle),),

                  Expanded(child:
                    Padding(padding: const EdgeInsets.all(5),
                      child:
                        Text(widget.question,
                          style: labelStyle2),
                    ),
                  ),
                ],
              ),
            ),

            Container(decoration: BoxDecoration(border: Border.all(color: Colors.grey, width:5)),
              child: Row(
                children: [
                  Padding(padding: const EdgeInsets.all(10),
                  child: Text('Conclusion:',
                    style: labelStyle),),

                  Expanded(child:Padding(padding: const EdgeInsets.all(5),
                    child: Text('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
                      style: labelStyle2),
                  ),
                  ),
                ],
              )
            ),

            Container(decoration: BoxDecoration(border: Border.all(color: Colors.grey, width:5)),
              child: Row(
                children: [
                  Padding(padding: const EdgeInsets.all(10),
                  child: Text('Analysis 1:',
                    style: labelStyle),),

                  Expanded(child:
                    Padding(padding: const EdgeInsets.all(5),
                      child: Text('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
                        style: labelStyle2),
                    ),
                  ),
                ],
              )
            ),

            Container(decoration: BoxDecoration(border: Border.all(color: Colors.grey, width:5)),
              child: Row(
                children: [
                  Padding(padding: const EdgeInsets.all(10),
              child: Text('Analysis 2:',
                  style: labelStyle),),

                  Expanded(child:
                    Padding(padding: const EdgeInsets.all(5),
                      child: Text('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
                        style: labelStyle2),
                    ),
                  ),
                ],
              )
            ),
          ],
        ),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}