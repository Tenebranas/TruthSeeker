class Job {
  final String question;
  final String source;

  Job({required this.question, required this.source});

  factory Job.fromfirestore(Map<String, dynamic> data) {
    return Job(
    question: data['question'] ?? 'enter question',
    source: data['source'] ?? 'google.com');
  }
  Map<String, dynamic> toFirestore(){
    return {
      'question': this.question,
      'source': this.source,
    };
  }
}

class Result {
  final String answer;
  final String summary;

  const Result({required this.answer, required this.summary});

  factory Result.fromfirestore(Map<String, dynamic> data) {
    return Result(
        answer: data['answer'] ?? 'your answer',
        summary: data['summary'] ?? 'your summary');
  }
  Map<String, dynamic> toFirestore(){
    return {
      'answer': this.answer,
      'summary': this.summary,
    };
  }
}

