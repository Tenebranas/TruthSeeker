import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'dataclasses.dart';

class JobsController{
  final CollectionReference collection =
  FirebaseFirestore.instance.collection('jobs');
  Future<DocumentReference> addJob(Job job) {
    return collection.add(job.toFirestore());
  }
}

class ResultsController{
  final CollectionReference collection =
  FirebaseFirestore.instance.collection('results');
  Stream<QuerySnapshot> getStream() {
    return collection.snapshots();
  }
  Future<Result> waitForResult (String ID) async {
    final docRef = collection.doc(ID);
    DocumentSnapshot? result;
    String test = '';
    StreamSubscription<DocumentSnapshot> sub = docRef.snapshots().listen(
          (event)
          {
            print("current data: ${event.data()}");
            test = event.data().toString();
            result = event;
          },
      onError: (error) => print("Listen failed: $error"),
    );
    print("=========================");
    print(test);
    print("=========================");
    while(test=="null" || test == "") {
      await Future.delayed(Duration(seconds: 1));
    }
    sub.cancel();
    return Result(answer:
    result!.get('answer'), summary:
    result!.get('summary'));
  }
}